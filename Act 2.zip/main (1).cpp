/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using namespace std;

int main() {
    // Variables para almacenar los números ingresados
    double numero1, numero2;

    // Solicitud de datos al usuario
    cout << "Escribe el primer número: ";
    cin >> numero1;

    cout << "Escribe el segundo número: ";
    cin >> numero2;

    // Operaciones
    double suma = numero1 + numero2;
    double resta = numero1 - numero2;
    double multiplicacion = numero1 * numero2;
    
    // Validar división entre cero
    double division;
    if (numero2 != 0) {
        division = numero1 / numero2;
    } else {
        cout << "No se puede dividir entre cero." << endl;
    }

    // Resultados
    cout << "La suma es: " << suma << endl;
    cout << "La resta es: " << resta << endl;
    cout << "La multiplicación es: " << multiplicacion << endl;

    if (numero2 != 0) {
        cout << "La división es: " << division << endl;
    }

    return 0;
}
