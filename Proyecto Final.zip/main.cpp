/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>
using namespace std;

class Empleado {
private:
    string nombre;
    string apellidoPaterno;
    string apellidoMaterno;
    int dia, mes, anio;

public:
    // Constructor
    Empleado(string _nombre, string _apP, string _apM, int _dia, int _mes, int _anio)
        : nombre(_nombre), apellidoPaterno(_apP), apellidoMaterno(_apM), dia(_dia), mes(_mes), anio(_anio) {}

    // Método para obtener la primera vocal interna del apellido paterno
    char obtenerVocalInterna(const string& apellido) {
        for (size_t i = 1; i < apellido.length(); ++i) {
            char c = toupper(apellido[i]);
            if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
                return c;
            }
        }
        return 'X'; // En caso de no encontrar vocal interna
    }

    // Método para generar el RFC
    string generarRFC() {
        string rfc;

        // Primera letra del apellido paterno
        rfc += toupper(apellidoPaterno[0]);

        // Primera vocal interna del apellido paterno
        rfc += obtenerVocalInterna(apellidoPaterno);

        // Inicial del apellido materno o X
        if (apellidoMaterno.empty()) {
            rfc += 'X';
        } else {
            rfc += toupper(apellidoMaterno[0]);
        }

        // Inicial del nombre
        rfc += toupper(nombre[0]);

        // Dos últimos dígitos del año
        rfc += to_string(anio).substr(2, 2);

        // Mes con dos cifras
        if (mes < 10) rfc += "0";
        rfc += to_string(mes);

        // Día con dos cifras
        if (dia < 10) rfc += "0";
        rfc += to_string(dia);

        return rfc;
    }

    void mostrarRFC() {
        cout << "El RFC generado es: " << generarRFC() << endl;
    }
};

int main() {
    string nombre, apellidoPaterno, apellidoMaterno;
    int dia, mes, anio;

    cout << "Ingrese el nombre: ";
    getline(cin, nombre);
    
    cout << "Ingrese el apellido paterno: ";
    getline(cin, apellidoPaterno);
    
    cout << "Ingrese el apellido materno (si no tiene, presione ENTER): ";
    getline(cin, apellidoMaterno);

    cout << "Ingrese el día de nacimiento (número): ";
    cin >> dia;

    cout << "Ingrese el mes de nacimiento (número): ";
    cin >> mes;

    cout << "Ingrese el año de nacimiento (completo): ";
    cin >> anio;

    Empleado nuevoEmpleado(nombre, apellidoPaterno, apellidoMaterno, dia, mes, anio);
    nuevoEmpleado.mostrarRFC();

    return 0;
}

